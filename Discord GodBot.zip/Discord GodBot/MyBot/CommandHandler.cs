﻿using System.Threading.Tasks;
using System.Reflection;
using Discord.Commands;
using Discord.WebSocket;
using Discord;
using System;
using Microsoft.Extensions.DependencyInjection;
using System.Linq;

namespace MyBot
{
    public class CommandHandler
    {
        private CommandService commands;
        private DiscordSocketClient client;
        private IServiceProvider map;

        public CommandHandler(IServiceProvider provider)
        {
            map = provider;
            client = map.GetService<DiscordSocketClient>();
            client.UserJoined += UserJoined;
            //client.UserJoined += AnnounceUserJoined;
            client.UserLeft += AnnounceLeftUser;
            //Send user message to get handled
            client.MessageReceived += HandleCommand;
            commands = map.GetService<CommandService>();

        }

        private async Task UserJoined(SocketGuildUser user)
        {
            var role = user.Guild.Roles.Where(has => has.Name.ToUpper() == "friends".ToUpper());
            await user.AddRolesAsync(role);
        }



        public async Task AnnounceLeftUser(SocketGuildUser user)
        {

            var channel = client.GetChannel(118513467220033537) as SocketTextChannel;
            EmbedBuilder embed = new EmbedBuilder();
            EmbedAuthorBuilder author = new EmbedAuthorBuilder();


            //No URL if user has default 
            if (user.GetAvatarUrl() != null)
            {
                author.WithIconUrl(user.GetAvatarUrl());
               
            }
            


            author.WithName(user.Username);
            embed.WithAuthor(author);
            embed.WithColor(255, 0, 0);
            embed.Title = $" Left the server";
            embed.Description = $" User:** {user.Mention}** \nTime: **{DateTime.Now}**";
            await channel.SendMessageAsync("", false, embed.Build());

        }

        public async Task AnnounceUserJoined(SocketGuildUser user)
        {
            
            var channel = client.GetChannel(118513467220033537) as SocketTextChannel;
            EmbedBuilder embed = new EmbedBuilder();
            EmbedAuthorBuilder author = new EmbedAuthorBuilder();
            //No URL if user has default 
            if (user.GetAvatarUrl() != null)
            {
                author.WithIconUrl(user.GetAvatarUrl());

            }


            
            author.WithName(user.Username);

            embed.WithAuthor(author);
            embed.WithColor(0, 255, 0);
             embed.Title = $" Welcome to the Discord!";
             embed.Description = $" User:** {user.Mention}** \nTime: **{DateTime.Now}**";
          
            await channel.SendMessageAsync("", false,embed.Build());
            
        }

    


        public async Task ConfigureAsync()
        {
            await commands.AddModulesAsync(Assembly.GetEntryAssembly());
        }

        public async Task HandleCommand(SocketMessage parameterMessage)
        {
            //Don't handle the command if it is a system message
            var message = parameterMessage as SocketUserMessage;
            if (message == null)
                return;
            var context = new SocketCommandContext(client, message);

            //Mark where the prefix ends and the command begins
            int argPos = 0;
            //Determine if the message has a valid prefix, adjust argPos
            if (message.HasStringPrefix("!", ref argPos))
            {
                if (message.Author.IsBot)
                    return;
                //Execute the command, store the result
                var result = await commands.ExecuteAsync(context, argPos, map);

                //If the command failed, notify the user
                if (!result.IsSuccess && result.ErrorReason != "Unknown command.")

                    await message.Channel.SendMessageAsync($"**Error:** {result.ErrorReason}");
            }




        }
    }
}